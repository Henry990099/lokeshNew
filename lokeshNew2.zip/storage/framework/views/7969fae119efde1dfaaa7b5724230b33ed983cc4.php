<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/layout.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<link rel="shortcut icon" href="assets/images/" type="image/x-icon">
<link rel="icon" href="assets/images/" type="image/x-icon">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700&display=swap" rel="stylesheet"><?php /**PATH /home/designstallionde/public_html/seal-configurator.designstalliondev.com/resources/views/includes/styles.blade.php ENDPATH**/ ?>