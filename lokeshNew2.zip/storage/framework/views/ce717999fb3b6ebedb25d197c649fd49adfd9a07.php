<?php
    $outputs = Sheets::spreadsheet('1Fk9HaiJ9tLT3bQDDE4bslky2dtC3MVOxPbflsM98wqo')->sheet('Webpage')->get();
    $output = [];
    $loop=-1;$increment=0;
    foreach($outputs as $key=>$value)
    { 
        if($key>=6)
        {
            $loop++; $increment=0;
            foreach($value as $key2=> $value2)
            {
                if($key2>=11)
                {
                    $output[$loop][$increment++]=$value2;
                }
            }
        }
    }
?>
             <thead class="last-step">
                        <?php $__currentLoopData = $output; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php if($key==0): ?>
                                <tr>
                                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2=>$value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e($value2); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endif; ?>
                        </thead>
                        <tbody>
                            <?php if($key!=0): ?>
                                <tr>
                                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2=>$value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($value2); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>    

     <?php /**PATH /home/designstallionde/public_html/lokesh.designstalliondev.com/resources/views/ajax/output.blade.php ENDPATH**/ ?>