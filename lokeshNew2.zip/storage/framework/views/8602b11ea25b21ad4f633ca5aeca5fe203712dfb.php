<!DOCTYPE html>
<html lang="en">
<head>
   <?php echo $__env->make("includes.compatibility", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <meta name="description" content="">
   <title>Seal Configurator | Login</title>
   <?php echo $__env->make("includes.styles", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</head>
<body>
   <?php echo $__env->make("includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
   <section class="login-section">
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
              
                  <div class="login-heading wow bounceIn" style="animation-delay: 0.2s;">
                     <h4>Login</h4>
                     <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                     <label class="custom-field one">
                        <input type="text" name="email" placeholder=" "/>
                        <span class="placeholder">User Name</span>
                     </label>
                     <label class="custom-field one">
                        <input type="password" name="password" placeholder=" "/>
                        <span class="placeholder">Password</span>
                     </label>
                     <div class="login-btn"><a href="index.php"><button>LOGIN</button></a></div>
                     </form>
                  </div>
              
            </div>
            <div class="col-md-2"></div>
         </div>
      </div>
   </section>
   <?php echo $__env->make("includes.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>
</html><?php /**PATH C:\Users\USER\Desktop\hk\lokeshNew2\resources\views/auth/login.blade.php ENDPATH**/ ?>