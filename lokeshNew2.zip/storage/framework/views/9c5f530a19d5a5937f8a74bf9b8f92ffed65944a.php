<?php



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("includes.compatibility", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <meta name="description" content="" />
    <title>Seal Configurator | Seal</title>
    <?php echo $__env->make("includes.styles", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<style type="text/css">
    @import url("https://fonts.googleapis.com/css?family=Roboto");

    /*------------------------*/
    input:focus,
    button:focus,
    .form-control:focus {
        outline: none;
        box-shadow: none;
    }
    .form-control:disabled,
    .form-control[readonly] {
        background-color: #fff;
    }
    /*----------step-wizard------------*/
    .d-flex {
        display: flex;
    }
    .justify-content-center {
        justify-content: center;
    }
    .align-items-center {
        align-items: center;
    }

    /*---------signup-step-------------*/
    .bg-color {
        background-color: #333;
    }
    .signup-step-container {
        padding: 88px 0px;
        padding-bottom: 60px;
    }

    .wizard .nav-tabs {
        position: relative;
        margin-bottom: 0;
        border-bottom-color: transparent;
    }

    .wizard > div.wizard-inner {
        position: relative;
        margin-bottom: 50px;
        text-align: center;
    }

    .connecting-line {
        height: 2px;
        background: #e0e0e0;
        position: absolute;
        width: 75%;
        margin: 0 auto;
        left: 0;
        right: 0;
        top: 15px;
        z-index: 1;
    }

    .wizard .nav-tabs > li.active > a,
    .wizard .nav-tabs > li.active > a:hover,
    .wizard .nav-tabs > li.active > a:focus {
        color: #555555;
        cursor: default;
        border: 0;
        border-bottom-color: transparent;
    }

    span.round-tab {
        width: 30px;
        height: 30px;
        line-height: 30px;
        display: inline-block;
        border-radius: 50%;
        background: #484e55;
        z-index: 2;
        position: absolute;
        left: 0;
        text-align: center;
        font-size: 19px;
        font-family: "Poppins", sans-serif;
        color: #fff;
        font-weight: 500;
        border: 1px solid #484e55;
        box-shadow: 0 2px 17px 13px rgb(46 46 46 / 69%);
        transition: 0.3s;
    }
    span.round-tab i {
        color: #555555;
    }
    .wizard li.active span.round-tab {
        background: #47a5f4;
        color: #fff;
        border-color: #47a5f4;
        box-shadow: 0 2px 17px 13px rgb(46 46 46 / 69%);
        transition: 0.3s;
    }
    .wizard li.active span.round-tab i {
        color: #5bc0de;
    }
    .wizard .nav-tabs > li.active > a i {
        font-size: 22px;
        text-align: center;
        color: #fff;
        font-weight: 400;
    }

    .wizard .nav-tabs > li {
        width: 25%;
    }

    .wizard li:after {
        content: " ";
        position: absolute;
        left: 46%;
        opacity: 0;
        margin: 0 auto;
        bottom: 0px;
        border: 5px solid transparent;
        border-bottom-color: red;
        transition: 0.1s ease-in-out;
    }

    .wizard .nav-tabs > li a {
        width: 30px;
        height: 30px;
        margin: 20px auto;
        border-radius: 100%;
        padding: 0;
        background-color: transparent;
        position: relative;
        top: 0;
    }
    .wizard .nav-tabs > li a i {
        position: absolute;
        top: 50px;
        font-style: normal;
        white-space: nowrap;
        left: 50%;
        transform: translate(-37%, -50%);
        color: #9ea2a7;
        font-size: 22px;
        text-align: center;
        font-weight: 400;
    }

    .wizard .nav-tabs > li a:hover {
        background: transparent;
    }

    .wizard .tab-pane {
        position: relative;
        padding-top: 20px;
    }

    .wizard h3 {
        margin-top: 0;
    }
    .prev-step,
    .next-step {
        font-size: 13px;
        /*padding: 8px 24px;*/
        border: none;
        cursor: pointer;
        border-radius: 4px;
    }
    .next-step {
        background-color: transparent;
        cursor: pointer;
    }
    .skip-btn {
        background-color: #cec12d;
    }
    .step-head {
        font-size: 20px;
        text-align: center;
        font-weight: 500;
        margin-bottom: 20px;
    }
    .term-check {
        font-size: 14px;
        font-weight: 400;
    }
    .custom-file {
        position: relative;
        display: inline-block;
        width: 100%;
        height: 40px;
        margin-bottom: 0;
    }
    .custom-file-input {
        position: relative;
        z-index: 2;
        width: 100%;
        height: 40px;
        margin: 0;
        opacity: 0;
    }
    .custom-file-label {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        z-index: 1;
        height: 40px;
        padding: 0.375rem 0.75rem;
        font-weight: 400;
        line-height: 2;
        color: #495057;
        background-color: #fff;
        border: 1px solid #ced4da;
        border-radius: 0.25rem;
    }
    .custom-file-label::after {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 3;
        display: block;
        height: 38px;
        padding: 0.375rem 0.75rem;
        line-height: 2;
        color: #495057;
        content: "Browse";
        background-color: #e9ecef;
        border-left: inherit;
        border-radius: 0 0.25rem 0.25rem 0;
    }
    .footer-link {
        margin-top: 30px;
    }
    .all-info-container {
    }
    .list-content {
        margin-bottom: 10px;
    }
    .list-content a {
        padding: 10px 15px;
        width: 100%;
        display: inline-block;
        background-color: #f5f5f5;
        position: relative;
        color: #565656;
        font-weight: 400;
        border-radius: 4px;
    }
    .list-content a[aria-expanded="true"] i {
        transform: rotate(180deg);
    }
    .list-content a i {
        text-align: right;
        position: absolute;
        top: 15px;
        right: 10px;
        transition: 0.5s;
    }
    .form-control[disabled],
    .form-control[readonly],
    fieldset[disabled] .form-control {
        background-color: #fdfdfd;
    }
    .list-box {
        padding: 10px;
    }
    .signup-logo-header .logo_area {
        width: 200px;
    }
    .signup-logo-header .nav > li {
        padding: 0;
    }
    .signup-logo-header .header-flex {
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .list-inline li {
        display: inline-block;
    }
    .pull-right {
        float: right;
    }
    /*-----------custom-checkbox-----------*/
    /*----------Custom-Checkbox---------*/
    input[type="checkbox"] {
        position: relative;
        display: inline-block;
        margin-right: 5px;
    }
    input[type="checkbox"]::before,
    input[type="checkbox"]::after {
        position: absolute;
        content: "";
        display: inline-block;
    }
    input[type="checkbox"]::before {
        height: 16px;
        width: 16px;
        border: 1px solid #999;
        left: 0px;
        top: 0px;
        background-color: #fff;
        border-radius: 2px;
    }
    input[type="checkbox"]::after {
        height: 5px;
        width: 9px;
        left: 4px;
        top: 4px;
    }
    input[type="checkbox"]:checked::after {
        content: "";
        border-left: 1px solid #fff;
        border-bottom: 1px solid #fff;
        transform: rotate(-45deg);
    }
    input[type="checkbox"]:checked::before {
        background-color: #18ba60;
        border-color: #18ba60;
    }

    @media (max-width: 767px) {
        .sign-content h3 {
            font-size: 40px;
        }
        .wizard .nav-tabs > li a i {
            display: none;
        }
        .signup-logo-header .navbar-toggle {
            margin: 0;
            margin-top: 8px;
        }
        .signup-logo-header .logo_area {
            margin-top: 0;
        }
        .signup-logo-header .header-flex {
            display: block;
        }
    }
    input[type="radio"] {
        accent-color: #47a5f4;
        cursor: pointer;
    }
    ul.list-inline.pull-right {
        position: fixed;
        top: 92%;
        right: 1%;
    }
    .first-btn a {
      font-size: 24px;
      color: #fff;
      background: #4a9ff0;
      padding: 3px 19px;
      border-radius: 28px;
      position: absolute;
      top: 20.6%;
      left: 20%;
      width: 12%;
      border: 1px solid #4a9ff0;
      text-align: center;
  }
  .first-btn a:hover{
    background: #fff;
    border: 1px solid #4a9ff0;
    color: #4a9ff0
}
.sec-btn a {
    font-size: 24px;
    color: #fff;
    background: #4a9ff0;
    padding: 3px 19px;
    border-radius: 28px;
    position: absolute;
    top: 10.9%;
    left: 35%;
    width: 16%;
    border: 1px solid #4a9ff0;
    text-align: center;
}
.sec-btn a:hover{
    background: #fff;
    border: 1px solid #4a9ff0;
    color: #4a9ff0
}
.third-btn a {
  font-size: 24px;
  color: #fff;
  background: #4a9ff0;
  padding: 3px 17px;
  border-radius: 28px;
  position: absolute;
  top: 19.9%;
  left: 50.5%;
  width: 15%;
  border: 1px solid #4a9ff0;
  text-align: center;
}
.third-btn a:hover{
    background: #fff;
    border: 1px solid #4a9ff0;
    color: #4a9ff0
}
.fourth-btn a {
   font-size: 24px;
   color: #fff;
   background: #4a9ff0;
   padding: 3px 17px;
   border-radius: 28px;
   position: absolute;
   top: 17.1%;
   left: 72.5%;
   width: 16%;
   border: 1px solid #4a9ff0;
   text-align: center;
}
.fourth-btn a:hover{
    background: #fff;
    border: 1px solid #4a9ff0;
    color: #4a9ff0
}
.five-btn a {
    font-size: 24px;
    color: #fff;
    background: #4a9ff0;
    padding: 3px 17px;
    border-radius: 28px;
    position: absolute;
    top: 85.1%;
    left: 10.5%;
    width: 18%;
    border: 1px solid #4a9ff0;
    text-align: center;
}
.five-btn a:hover{
    background: #fff;
    border: 1px solid #4a9ff0;
    color: #4a9ff0
}
.six-btn a {
    font-size: 24px;
    color: #fff;
    background: #4a9ff0;
    padding: 3px 17px;
    border-radius: 28px;
    position: absolute;
    top: 84.1%;
    left: 51.1%;
    width: 11%;
    border: 1px solid #4a9ff0;
    text-align: center;
}
.six-btn a:hover{
    background: #fff;
    border: 1px solid #4a9ff0;
    color: #4a9ff0
}
</style>
<body>
    <?php echo $__env->make("includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section class="signup-step-container" style="margin-bottom: 3rem;">
        <div class="container-fluid">
            <div class="row d-flex justify-content-center">
                <div class="col-md-12">
                    <div class="wizard">
                        <div class="wizard-inner">
                            <div class="connecting-line"></div>
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" aria-expanded="true">
                                        <span class="round-tab">1 </span> <i><h6>Select Seal Type</h6></i>
                                    </a>
                                </li>
                                <li role="presentation" class="disabled">
                                    <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" aria-expanded="false">
                                        <span class="round-tab">2</span><i> <h6>Material Selection</h6></i>
                                    </a>
                                </li>
                                <li role="presentation" class="disabled">
                                    <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab">
                                        <span class="round-tab">3</span><i> <h6>Seal/Gland Dimensions</h6></i>
                                    </a>
                                </li>
                                <li role="presentation" class="disabled">
                                    <a class="step4" href="#step4" data-toggle="tab" aria-controls="step4" role="tab">
                                        <span class="round-tab">4</span><i> <h6>Hooray, You made it</h6></i>
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <div class="tab-content" id="main_form">
                            <div class="tab-pane active" role="tabpanel" id="step1">
                                <div class="container-fluid mt-5">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="seal-type"><h6>SEAL TYPE</h6></div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="assets/images/seal-img.jpg" class="img-fluid rounded" alt="" width="100%" />
                                            <div class="first-btn ">
                                                <a href="" data-id="Wiper" class="category " >Wiper</a>
                                            </div>
                                            <div class="sec-btn ">
                                                <a href="" data-id="Rod Seal" class="category " >Road Seal</a>
                                            </div>
                                            <div class="third-btn ">
                                                <a href="" data-id="Wear Ring" class="category " >Wear Ring</a>
                                            </div>
                                            <div class="fourth-btn ">
                                                <a href="" data-id="Piston Seal" class="category " >Piston Seal</a>
                                            </div>
                                            <div class="five-btn ">
                                                <a href="" data-id="Back-up Ring" class="category ">Back-Up Ring</a>
                                            </div>
                                            <div class="six-btn ">
                                                <a href="" data-id="Gasket" class="category " >GasKet</a>
                                            </div>
                                        </div>
                                        <div class="col-md-6 rounded">
                                            <img src="assets/images/seal-img1.jpg" class="img-fluid rounded category" width="100%" alt="" data-id="Rotary Seal"  />
                                        </div>
                                    </div>
                                   
                                <div id="sub_category_fetch">

                                </div>

                                </div>
                                <ul class="list-inline pull-right">
                                    <li>
                                        <button id="nextStep" type="button" class="default-btn next-step"><i class="fa-solid fa-arrow-right"></i></button>
                                    </li>
                                </ul>
                            </div>

                            <div class="tab-pane" role="tabpanel" id="step2">
                                <div class="container mt-5">
                                    <div class="row">
                                        <div class="col-md-5 radio-heading">
                                            <div class="measure-type"><h6>MEASUREMENTS AND MATERIAL</h6></div>
                                            <input type="radio" id="html" class="inchMetric" name="fav_language" value="Inch" />
                                            <label for="html">Inch</label>
                                            <input type="radio" id="css" class="inchMetric" name="fav_language" class="ml-4" value="Metric" />
                                            <label for="css">Metric</label>
                                            <label class="custom-field-inv-select one mt-4">
                                                <select id="select_id">
                                                    <option>Please Select</option>
                                                    <option value="POLYURETHANE" class="material">POLYURETHANE</option>
                                                    <option value="ELASTOMERS" class="material">ELASTOMERS</option>
                                                    <option value="PTFE" class="material">PTFE</option>
                                                    <option value="THERMOPLASTIC">THERMOPLASTIC</option>
                                                </select>
                                                <span class="placeholder">RAW MATERIAL</span>
                                            </label>
                                            <label class="custom-field-inv-select one mt-3">
                                                <select id="material_selecton">
                                                    <option>Please Select</option>
                                                </select>
                                                <span class="placeholder">MATERIAL SELECTION</span>
                                            </label>
                                        </div>
                                        <div class="col-md-2"></div>
                                        <div class="col-md-5">
                                            <div class="shA"><h6>HPU RED 95 Sh A</h6></div>
                                            <div class="text-center">
                                                <img src="assets/images/step-2.jpg" alt="" class="img-fluid" />
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2"></div>
                                                <div class="col-md-8">
                                                    <div class="shA-ul mt-4">
                                                        <ul>
                                                            <li>FDA APPROVED</li>
                                                            <li>MAX Service Temp 115C</li>
                                                            <li>MIN Service Temp -20C</li>
                                                            <li>Hardness Sh A 95+/-2</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="feed-back">
                                                <h4>Feedback</h4>
                                            </div>
                                            <div class="invan-feild mt-4">
                                                <input type="text" placeholder="Please input your valuable feedback/suggestions here" name="" style="height: 68px !important; font-size: 20px; border-radius: 10px;" />
                                                <div class="d-flex justify-content-center">
                                                    <button class="submit_btn">SUBMIT <i class="fa-solid fa-envelope"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <ul class="list-inline pull-right left">
                                   <li><button type="button" class="default-btn prev-step" ><i class="fa-solid fa-arrow-left"></i></button></li>
                               </ul>
                               <ul class="list-inline pull-right">
                                <li>
                                    <button type="button" class="default-btn next-step"><i class="fa-solid fa-arrow-right"></i></button>
                                </li>
                            </ul>
                        </div>

                        <!-- STEP O3 -->

                        <div class="tab-pane" role="tabpanel" id="step3">
                            <div class="container-fluid mt-5">
                                <div class="row">
                                    <div class="col-md-5 radio-heading pl-5">
                                        <div class="measure-type"><h6>INPUT YOUR SEAL DIMENSIONS</h6></div>
                                        <p>Do you have Gland Dimensions or Seal Dimensions?</p>
                                        <p class="mb-4">Please Select as applicable.</p>
                                        <input type="radio" id="html" class="sealGland" name="fav_language" value="Seal" />
                                        <label for="html">Seal Dimensions </label>
                                        <input type="radio" id="css" name="fav_language" class="ml-4 sealGland" value="Gland" />
                                        <label for="css">Gland Dimensions</label>
                                        <div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="invan-feild mt-4">
                                                        <input type="text" class="id" id="id" placeholder="ID" name="ID" />
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="invan-feild mt-4">
                                                        <input type="text" class="od" id="od" placeholder="OD" name="OD" />
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="invan-feild mt-4">
                                                        <input type="text" class="ht" id="ht" placeholder="HT" name="HT" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="limits mt-4">
                                            <p>Size Limits: Min ID = 10mm or 3/8 in Max OD = 609 mm or 24 in</p>
                                        </div>
                                        <div class="quantity">
                                            <h6>QUANTITY</h6>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="invan-feild mt-2 pl-3 trash-icon field_wrapper">
                                                        <input type="number" placeholder="Quantity" class="quantity" name="quantity[]" style="padding: 14px 40px 12px 12px;">
                                                       
                                                    </div>
                                                    <div class="plus add_button"><i class="fa-solid fa-plus"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-5">
                                            <div class="col-md-6 split-box">
                                                <p class="mb-2">Split</p>
                                                <input type="radio" id="html" name="fav_language" value="HTML" />
                                                <label for="html">Yes </label>
                                                <input type="radio" id="css" name="fav_language" class="ml-3" value="CSS" />
                                                <label for="css">No</label>
                                                <p class="mb-2 mt-3">Type Of Cut</p>
                                                <input type="radio" id="html" name="fav_language" value="HTML" />
                                                <label for="html">Butt Cut </label>
                                                <input type="radio" id="css" name="fav_language" class="ml-3" value="CSS" />
                                                <label for="css">Scaft Cut</label>
                                                <div class="invan-feild mt-2 mb-2">
                                                    <input type="text" placeholder="HT" name="" />
                                                </div>
                                                <input type="radio" id="html" name="fav_language" value="HTML" />
                                                <label for="html">Gap</label>
                                                <input type="radio" id="css" name="fav_language" class="ml-3" value="CSS" />
                                                <label for="css">No Gap</label>
                                                <div class="invan-feild mt-2 mb-2">
                                                    <input type="text" placeholder="Gap Thickness" name="" />
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="notes">
                                                    <textarea placeholder="Additional Notes"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="d-flex justify-content-space-around">
                                            <div class="p-3"><img src="assets/images/step-3.jpg" alt="" class="img-fluid" /></div>
                                            <div class="p-3"><img src="assets/images/step-3-1.jpg" alt="" class="img-fluid" /></div>
                                        </div>
                                                <!--  <div class="col-md-4">
                                                <div class="text-center">
                                                    <img src="assets/images/step-3-1.jpg" alt="" class="img-fluid" />
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-2"></div>
                                                    <div class="col-md-8">
                                                        <div class="shA-ul mt-4">
                                                            <ul>
                                                                <li>FDA APPROVED</li>
                                                                <li>MAX Service Temp 115C</li>
                                                                <li>MIN Service Temp -20C</li>
                                                                <li>Hardness Sh A 95+/-2</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2"></div>
                                                </div>
                                            </div> -->
                                        </div>
                                    </div>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="feed-back">
                                                    <h4>Feedback</h4>
                                                </div>
                                                <div class="invan-feild mt-4">
                                                    <input type="text" placeholder="Please input your valuable feedback/suggestions here" name="" style="height: 68px !important; font-size: 20px; border-radius: 10px;" />
                                                    <div class="d-flex justify-content-center">
                                                        <button class="submit_btn">SUBMIT <i class="fa-solid fa-envelope"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="list-inline pull-right">
                                        <li>
                                            <button type="button" class="default-btn next-step"><i class="fa-solid fa-arrow-right"></i></button>
                                        </li>
                                    </ul>
                                    <!--<ul class="list-inline pull-right">-->
                                        <!--  <li><button type="button" class="default-btn prev-step">Back</button></li>-->
                                        <!--  <li><button type="button" class="default-btn next-step skip-btn">Skip</button></li>-->
                                        <!--  <li><button type="button" class="default-btn next-step">Continue</button></li>-->
                                        <!--</ul>-->
                                    </div>
                                </div>
                                <div class="tab-pane" role="tabpanel" id="step4">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12 radio-heading">
                <div class="measure-type"><h6>FINAL QUOTE</h6></div>
                <p class="mb-3">Rush Order</p>
                <input type="radio" id="html" name="fav_language" value="HTML" />
                <label for="html">Yes</label>
                <input type="radio" id="css" name="fav_language" class="ml-4" value="CSS" />
                <label for="css">No</label>
                <div class="table-responsive mt-4">
                    <table class="table" id="table">
                        
                    </table>
                </div>
                <div class="downloads mt-4">
                    <div>
                        <a href="#"> <i class="fa-solid fa-file"></i><span style="color: #47a5f4;"> Save Quote</span> </a>
                    </div>
                    <div>
                        <a href="#"><i class="fa-solid fa-file-arrow-down" style="color: green;"></i><span style="color: green;"> Download Quote</span> </a>
                    </div>
                    <div>
                        <a href="#"><i class="fa-solid fa-envelope" style="color: orange;"></i><span style="color: orange;"> E-mail Quote</span> </a>
                    </div>
                </div>
                <div class="d-flex justify-content-center mt-4 mb-5">
                    <button class="submit_btn">PLACE ORDER</button>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="feed-back">
                    <h4>Feedback</h4>
                </div>
                <div class="invan-feild mt-4">
                    <input type="text" placeholder="Please input your valuable feedback/suggestions here" name="" style="height: 68px !important; font-size: 20px; border-radius: 10px;" />
                    <div class="d-flex justify-content-center">
                        <button class="submit_btn">SUBMIT <i class="fa-solid fa-envelope"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--<ul class="list-inline pull-right">-->
        <!--  <li><button type="button" class="default-btn prev-step">Back</button></li>-->
        <!--  <li><button type="button" class="default-btn next-step">Finish</button></li>-->
        <!--</ul>-->
        <ul class="list-inline pull-right left">
            <li><button type="button" class="default-btn prev-step" ><i class="fa-solid fa-arrow-left"></i></button></li>
        </ul>
    </div>
    <div class="clearfix"></div>
</div>
</div>
                           
                       </div>
                   </div>
               </div>
           </section>

           <?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           <?php echo $__env->make("includes.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           <script>
            function importData() {
                let input = document.createElement("input");
                input.type = "file";
                input.onchange = (_) => {
                    let files = Array.from(input.files);
                    console.log(files);
                };
                input.click();
            }
        </script>
        <script type="text/javascript">
            $(document).ready(function () {
                $(".nav-tabs > li a[title]").tooltip();
                $('a[data-toggle="tab"]').on("shown.bs.tab", function (e) {
                    var target = $(e.target);

                    if (target.parent().hasClass("disabled")) {
                        return false;
                    }
                });

                $(".next-step").click(function (e) {
                    var active = $(".wizard .nav-tabs li.active");
                    active.next().removeClass("disabled");
                    nextTab(active);
                });
                $(".prev-step").click(function (e) {
                    var active = $(".wizard .nav-tabs li.active");
                    prevTab(active);
                });
            });

            function nextTab(elem) {
                $(elem).next().find('a[data-toggle="tab"]').click();
            }
            function prevTab(elem) {
                $(elem).prev().find('a[data-toggle="tab"]').click();
            }

            $(".nav-tabs").on("click", "li", function () {
                $(".nav-tabs li.active").removeClass("active");
                $(this).addClass("active");
            });
        </script>
        <script>
            $(".category").click(function (e) {
                $("#sub_category_fetch").html("").slideToggle();
                var urllink =  "<?php echo e(URL::asset('step-two')); ?>/"
                e.preventDefault();
                var category=$(this).attr("data-id");
                $.ajax({
                method:'GET',
                url: urllink+category,
                success:function(result){
                    $("#sub_category_fetch").html(result).slideToggle();
                },
            });
            });
        </script>
         <script>
            $('#select_id').on('change',function (e) {
                var urllink =  "<?php echo e(URL::asset('measurement-material')); ?>/"
                e.preventDefault();
                var material=$(this).val();
                $.ajax({
                method:'GET',
                url: urllink+material,
                success:function(result){
                    $.each(result,function(val,key){
                        $("#material_selecton").append('<option value=' + val + '>' + val + '</option>');
                    })
                },
                });
            });
        </script>
        <script>
            $(".inchMetric").change(function(){ 
                if( $(this).is(":checked") ){ 
                    var inchMetric = $(this).val(); 
                    var urllink =  "<?php echo e(URL::asset('measurements')); ?>/"
                    $.ajax({
                    method:'GET',
                    url: urllink+inchMetric,
                    success:function(result){
                        console.log(result);
                    },
                });
                }
            });
        </script>
          <script>
            $('#material_selecton').on('change',function (e) {
                var urllink =  "<?php echo e(URL::asset('material-selection')); ?>/"
                e.preventDefault();
                var selection=$(this).val();
                $.ajax({
                method:'GET',
                url: urllink+selection,
                success:function(result){
                    console.log(result);
                },
                });
            });
        </script>
          <script>
            $(".sealGland").change(function(){ 
                var urllink =  "<?php echo e(URL::asset('seal-gland')); ?>/"
                if( $(this).is(":checked") ){ 
                    var sealGland = $(this).val(); 
                    $.ajax({
                    method:'GET',
                    url: urllink+sealGland,
                    success:function(result){
                        console.log(result);
                    },
                });
                }
            });
        </script>

<script>
    $('#id').on('change', function() {
        var urllink =  "<?php echo e(URL::asset('id')); ?>/"
        var id = $('#id').val();
        $.ajax({
            method:'GET',
            url: urllink+id,
            success:function(result){
                console.log(result);
            },
        });
    });
</script>
<script>
    $('.quantity').on('change', function() {
        var urllink =  "<?php echo e(URL::asset('quantity')); ?>/"
        var values = $("input[name='quantity[]']").map(function(){return $(this).val();}).get();
        $.ajax({
            type:'POST',
            url: urllink,
            data: {
                   _token: '<?php echo csrf_token(); ?>',
                   quantity: values
                 },
            success: function(result) {
                console.log(result);
                }
            });
         });
</script>
<script>
    $('#od').on('change', function() {
        var urllink =  "<?php echo e(URL::asset('od')); ?>/"
        var od = $('#od').val();
        $.ajax({
            method:'GET',
            url: urllink+od,
            success:function(result){
                console.log(result);
            },
        });
    });
</script>    
<script>    
    $('#ht').on('change', function() {
        var urllink =  "<?php echo e(URL::asset('ht')); ?>/"
        var ht = $('#ht').val();
        $.ajax({
            method:'GET',
            url: urllink+ht,
            success:function(result){
                console.log(result);
            },
        });
    });
</script>
 
<script>
    $('#nextStep,#step4').on('click',function(){
        var urllink =  "<?php echo e(URL::asset('output')); ?>/"
        $.ajax({
            url: urllink,
            method: 'GET',
            success:function(result){
                $("#table").html(result);
            }
        });
    });
    </script>
   

<script type="text/javascript">
    $(document).ready(function(){
        var maxField = 5; 
        var addButton = $('.add_button');
        var wrapper = $('.field_wrapper'); 
        var fieldHTML = '<div><input type="text" name="quantity[]" class="quantity" placeholder="Quantity" value=""/><a href="javascript:void(0);" class="remove_button"> <i class="fas fa-solid fa-trash"></i></a></div>'; //New input field html 
        var x = 1;
        
        $(addButton).click(function(){
            if(x < maxField){ 
                x++; 
                $(wrapper).append(fieldHTML); 
            }
        });
        
        $(wrapper).on('click', '.remove_button', function(e){
            e.preventDefault();
            $(this).parent('div').remove(); 
            x--; 
        });
    });
    </script>
   
        
    </body>
    </html>
<?php /**PATH C:\Users\USER\Desktop\hk\lokesh\lokesh\resources\views/index.blade.php ENDPATH**/ ?>