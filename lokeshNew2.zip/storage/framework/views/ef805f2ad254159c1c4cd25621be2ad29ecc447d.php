<?php if(!empty($dataProfileAndSqueeze['backup']) && $dataProfileAndSqueeze['backup']=="Y"): ?>
<script>
  backup="Y";
  dimensionChange2("Seal",backup);
</script>
<div class="col-md-5 radio-heading">
    <div class="measure-type">
      <h6>BACKUP MATERIAL SELECTION</h6>
    </div>
    
    <label class="custom-field-inv-select one mt-4">
      <select class="backup_material">
        <option>Please Select</option>
        <option value="POLYURETHANE" class="material">POLYURETHANE</option>
        <option value="ELASTOMERS" class="material">ELASTOMERS</option>
        <option value="PTFE" class="material">PTFE</option>
        <option value="THERMOPLASTIC">THERMOPLASTIC</option>
      </select>
      <span class="placeholder">MATERIAL FAMILY</span>
    </label>
    <label class="custom-field-inv-select one mt-3">
      <select id="backup_selecton">
        <option>Please Select</option>
      </select>
      <span class="placeholder">MATERIAL SELECTION</span>
    </label>
</div>
<?php endif; ?>
<?php if(!empty($dataProfileAndSqueeze['noofseals']) && $dataProfileAndSqueeze['noofseals'] == "3" ): ?>
                      
<div class="col-md-5 radio-heading">
    <div class="measure-type">
      <h6>ENERGIZER</h6>
    </div>
    <label class="custom-field-inv-select one mt-4">
      <select class="energizer">
        <option>Please Select</option>
        <option value="FKM" class="energ">FKM</option>
        <option value="DKM" class="energ">DKM</option>
        <option value="SILICONE" class="energ">SILICONE</option>
      </select>
      <span class="placeholder">MATERIAL FAMILY</span>
    </label>
</div>

<?php endif; ?>

<script>
    $('.backup_material').on('change',function (e) {
        var urllink =  "<?php echo e(URL::asset('backup-material')); ?>/"
        e.preventDefault();
        var backup=$(this).val();
        $.ajax({
        method:'GET',
        url: urllink+backup,
        success:function(result){
            $("#backup_selecton").empty();
            $.each(result,function(val,key){                       
                $("#backup_selecton").append('<option value=' + val + '>' + val + '</option>');
            });
        },
        });
    });
</script>
<script>
  $('#backup_selecton').on('change',function (e) {
      var urllink =  "<?php echo e(URL::asset('backup-material-selection')); ?>/"
      e.preventDefault();
      var selection=$(this).val();
      $.ajax({
      method:'GET',
      url: urllink+selection,
      success:function(result){
        console.log(result)
          },
      });
  });
</script>
<script>
  $('.energizer').on('change',function (e) {
      var urllink =  "<?php echo e(URL::asset('energizer')); ?>/"
      e.preventDefault();
      var energizer=$(this).val();
      $.ajax({
      method:'GET',
      url: urllink+energizer,
      success:function(result){
        console.log(result)
          },
      });
  });
</script><?php /**PATH C:\xampp\htdocs\google_sheet\resources\views/ajax/backup_material.blade.php ENDPATH**/ ?>