
<script src="<?php echo e(URL::asset('assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/custom.js')); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
	new WOW().init();
</script>
<?php /**PATH C:\Users\USER\Desktop\hk\lokeshNew2\resources\views////includes/scripts.blade.php ENDPATH**/ ?>