<header>
	<div class="container-fluid">
		<div class="row d-flex align-items-center">
			<div class="col-md-6">
				<div>
					<a href="<?php echo e(url('/')); ?>"><h6>Seal Configurator <sup>TM</sup></h6></a>
				</div>
			</div>
			<div class="col-md-6">
				<div class="logout"><a href="login.php"><i class="fa-solid fa-right-to-bracket text-white wow bounceIn" style="animation-delay: 0.5s;"></i></a></div>
			</div>
		</div>
	</div>
</header>
<?php /**PATH /home/designstallionde/public_html/lokesh.designstalliondev.com/resources/views////includes/header.blade.php ENDPATH**/ ?>