<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make("../includes.compatibility", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <meta name="description" content="" />
  <title>Seal Configurator | Home</title>
  <?php echo $__env->make("../includes.styles", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>>
</head>
<body>
  <?php echo $__env->make("../includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <section style="margin-top: 6rem; margin-bottom: 3rem;">
  <form id="inventory">
    <div class="container-fluid pl-5">
      <div class="row">
        <div class="col-md-2">
          <div class="invantory-btn  wow bounceIn" style="animation-delay: 0.1s;">
            <button onclick="importData()"><i class="fa-solid fa-file"></i> UPDATE INVENTORY</button>
          </div>
        </div>
      </div>
      <div class="row wow bounceInRight" style="animation-delay: 0.2s;">
        <div class="col-md-8">
          <div class="invan-feild mt-4">
            <input type="text" placeholder="Hello Are You Ready- Lets do this" name="" />
          </div>
          <label class="custom-field-inv one">
            <input type="text" name="setup" placeholder=" " />
            <span class="placeholder">Setup Cpst/hr</span>
          </label>
          <label class="custom-field-inv one">
            <input type="text" name="qcinspector" placeholder=" " />
            <span class="placeholder">Qc InspectorCost/hr</span>
          </label>
          <label class="custom-field-inv one">
            <input type="text" name="toolingcost" placeholder=" " />
            <span class="placeholder">Tooling Cost/pr</span>
          </label>
          <label class="custom-field-inv one">
            <input type="text" placeholder=" "name="rejectionrate" />
            <span class="placeholder" >rejection Rate (%)</span>
          </label>
        </div>
      </div>

      <div class="row wow bounceInRight" style="animation-delay: 0.4s;">
        <div class="col-md-8">
          <div class="mt-4 quality-heading">
            <h5>Quality Control Time</h5>
          </div>
        </div>
      </div>

      <div class="row wow bounceInRight" style="animation-delay: .4s;">
        <div class="col-md-3">
          <div class="mt-5 lot-size">
            <h5>Lot Size</h5>
            <h5>Quality Control Time (hr)</h5>
          </div>
          <div class="mt-2 lot-size">
            <h5>1-100</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="qctime1" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>101-500</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="qctime2" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>501-1000</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="qctime3" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>1001-up</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="qctime4" />
            </div>
          </div>
        </div>
      </div>

      <div class="row wow bounceInRight" style="animation-delay: 0.6s;">
        <div class="col-md-8">
          <div class="mt-4 quality-heading">
            <h5>Set up Time/Cost of prep</h5>
          </div>
        </div>
      </div>

      <div class="row wow bounceInRight" style="animation-delay: 0.6s;">
        <div class="col-md-3">
          <div class="mt-5 lot-size">
            <h5>Seal Size (mm)</h5>
            <h5>Setup time (hr)</h5>
          </div>
          <div class="mt-2 lot-size">
            <h5>1-50</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="setuptime1" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>101-500</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="setuptime2" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>501-1000</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="setuptime3" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>1001-up</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="setuptime4" />
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8">
          <label class="custom-field-inv one">
            <input type="text" placeholder="" name="aqllevel" />
            <span class="placeholder">AQL Level</span>
          </label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8">
          <div class="mt-4 quality-heading">
            <h5>Lead Time</h5>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="mt-5 lot-size">
            <h5>Lot Size (Pcs)</h5>
            <h5>(Days)</h5>
          </div>
          <!-- <div class="mt-2 lot-size">
            <div class="invan-feild">
              <input type="text" placeholder="5" name="" />
            </div>
            <div class="invan-feild">
              <input type="text" placeholder="5" name="" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <div class="invan-feild">
              <input type="text" placeholder="5" name="" />
            </div>
            <div class="invan-feild">
              <input type="text" placeholder="6" name="" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <div class="invan-feild">
              <input type="text" placeholder="5" name="" />
            </div>
            <div class="invan-feild">
              <input type="text" placeholder="7" name="" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <div class="invan-feild">
              <input type="text" placeholder="5" name="" />
            </div>
            <div class="invan-feild">
              <input type="text" placeholder="8" name="" />
            </div>
          </div> -->
         
          <div class="mt-2 lot-size">
            <h5>1-100</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="leadtime1" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>101-25</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="leadtime2" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>251-500</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="leadtime3" />
            </div>
          </div>
          <div class="mt-2 lot-size">
            <h5>501-up</h5>
            <div class="invan-feild">
              <input type="text" placeholder="0.5" name="leadtime4" />
            </div>
          </div>
        </div>
      </div>


      <div class="row">
        <div class="col-md-4">
          <div class="mt-4 quality-heading">
            <h5>Qty Price Selection</h5>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="table-responsive mt-4">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col quality-heading"><h5>Pieces</h5></th>
                  <th scope="col quality-heading"><h5>Price Selector</h5></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="invan-feild">
                    <h5>1-500</h5>
                    </div>
                  </td>
                  <td>
                    <label class="custom-field-inv-select one">
                      <select name="qty1">
                        <option value="Max">Max </option>
                        <option value="Min">Min</option>
                        <option value="Avg">Avg</option>
                      </select>
                      <span class="placeholder">Custom Rank</span>
                    </label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="invan-feild">
                    <h5>501-1000</h5>
                    </div>
                  </td>
                  <td>
                    <label class="custom-field-inv-select one">
                    <select name="qty2">
                        <option value="Max">Max </option>
                        <option value="Min">Min</option>
                        <option value="Avg">Avg</option>
                      </select>>
                      <span class="placeholder">Custom Rank</span>
                    </label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="invan-feild">
                      <h5>1001-up</h5>
                    </div>
                  </td>
                  <td>
                    <label class="custom-field-inv-select one">
                    <select name="qty3">
                        <option value="Max">Max </option>
                        <option value="Min">Min</option>
                        <option value="Avg">Avg</option>
                      </select>
                      <span class="placeholder">Custom Rank</span>
                    </label>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8">
          <div class="mt-4 quality-heading">
            <h5>O-Ring Cost</h5>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <div class="table-responsive mt-4">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col quality-heading"><h5></h5></th>
                  <th scope="col quality-heading"><h5>FKM</h5></th>
                  <th scope="col quality-heading"><h5>NBR</h5></th>
                  <th scope="col quality-heading"><h5>SILICON</h5></th>
                </tr>
              </thead>
              <thead>
                <tr>
                  <th scope="col quality-heading"><h5>Size (mm)</h5></th>
                  <th scope="col quality-heading"><h5>Cost/pc</h5></th>
                  <th scope="col quality-heading"><h5>Cost/pc</h5></th>
                  <th scope="col quality-heading"><h5>Cost/pc</h5></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="1-50" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="51-100" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="101-150" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="151-200" name="" />
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$0.15" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$0.15" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$2.25" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$2.25" name="" />
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$0.20" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$0.40" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$2.00" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$3.00" name="" />
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="0.40" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="0.50" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="5.00" name="" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="7.00" name="" />
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8">
          <label class="custom-field-inv one">
            <input type="text" placeholder=" " name="mtrl" />
            <span class="placeholder">Surcharge Mtrl (Enter in %)</span>
          </label>
          <label class="custom-field-inv one">
            <input type="text" placeholder=" " name="overhead" />
            <span class="placeholder">Overhead (Enter in %)</span>
          </label>
          <label class="custom-field-inv one">
            <input type="text" placeholder=" " name="overall" />
            <span class="placeholder">Surcharge Overall(Enter in %)</span>
          </label>
          <label class="custom-field-inv one">
            <input type="text" placeholder=" " name="discount" />
            <span class="placeholder">Discount (Enter in %)</span>
          </label>
        </div>
      </div>

      <div class="row mt-5">
        <div class="col-md-6">
          <div class="table-responsive mt-4">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col quality-heading"><h5></h5></th>
                  <th scope="col quality-heading"><h5>Seal Size (mm)</h5></th>
                  <th scope="col quality-heading"><h5>Hourly Cost</h5></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="quality-heading">
                      <h5>Machine 1</h5>
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="0-300" name="m1sealsize" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$98.00" name="m1cost" />
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="quality-heading">
                      <h5>Machine 2</h5>
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="300-650" name="m2sealsize" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$98.00" name="m2cost" />
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="quality-heading">
                      <h5>Machine 3</h5>
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="650-1500" name="m3sealsize" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$98.00" name="m3cost" />
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="quality-heading">
                      <h5>Machine 4</h5>
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="501-1000" name="m4sealsize" />
                    </div>
                  </td>
                  <td>
                    <div class="invan-feild">
                      <input type="text" placeholder="$98.00" name="m4cost" />
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8">
          <label class="custom-field-inv one">
            <input type="text" placeholder=" " name="maxorderqty" />
            <span class="placeholder">Max Order Qty</span>
          </label>
          <label class="custom-field-inv-select one">
            <select name="customrank" >
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
            </select>
            <span class="placeholder">Custom Rank</span>
          </label>
          <label class="custom-field-inv-select one">
            <select name="custom">
              <option value="Yes">Yes </option>
              <option value="No">No</option>
            </select>
            <span class="placeholder">Custom Rank</span>
          </label>
          <label class="custom-field-inv one">
            <input type="text" placeholder=" " name="bandsaw" />
            <span class="placeholder">Band Saw Thickness</span>
          </label>
        </div>
      </div>
      <button class="submit_btn">SUBMIT</button>
    </div>
</form>
  </section>

  <?php echo $__env->make("../includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make("../includes.scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
    function importData() {
  let input = document.createElement('input');
  input.type = 'file';
  input.onchange = _ => {
    // you can use this method to get file and perform respective operations
            let files =   Array.from(input.files);
            console.log(files);
        };
  input.click();
  
}
  </script>
  <script>
  $("#inventory").submit(function(stay){
   var formdata = $(this).serialize();
    $.ajax({
        type: 'POST',
        url: "<?php echo e(url('inventory')); ?>",
        data: {
               _token: '<?php echo csrf_token(); ?>',
               data: formdata
             },
        success: function (data) {
           console.log(data);
        },
    });
    stay.preventDefault(); 
});
</script>
</body>
</html>
<?php /**PATH C:\Users\Furqan\Downloads\g_sheet\resources\views/admin/index.blade.php ENDPATH**/ ?>