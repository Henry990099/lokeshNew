<?php
    $outputs = Sheets::spreadsheet('1Fk9HaiJ9tLT3bQDDE4bslky2dtC3MVOxPbflsM98wqo')->sheet('Webpage')->get();
    $output = [];
    $loop=-1;$increment=0;
    foreach($outputs as $key=>$value)
    { 
        if($key>=6)
        {
            $loop++; $increment=0;
            foreach($value as $key2=> $value2)
            {
                if($key2>=11)
                {
                    $output[$loop][$increment++]=$value2;
                }
            }
        }
    }
?>

<thead class="last-step">
                            <tr>
                                <th scope="col"><?php echo e($output[0][0]); ?></th>
                                <th scope="col"><?php echo e($output[0][1]); ?></th>
                                <th scope="col"><?php echo e($output[0][2]); ?></th>
                                <th scope="col"><?php echo e($output[0][3]); ?></th>
                                <th scope="col"><?php echo e($output[0][4]); ?></th>
                                <th scope="col"><?php echo e($output[0][5]); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($output[1][0]); ?></td>
                                <td><?php echo e($output[1][1]); ?></td>
                                <td><?php echo e($output[1][2]); ?></td>
                                <td><?php echo e($output[1][3]); ?></td>
                                <td><?php echo e($output[1][4]); ?></td>
                                <td><?php echo e($output[1][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[2][0]); ?></td>
                                <td><?php echo e($output[2][1]); ?></td>
                                <td><?php echo e($output[2][2]); ?></td>
                                <td><?php echo e($output[2][3]); ?></td>
                                <td><?php echo e($output[2][4]); ?></td>
                                <td><?php echo e($output[2][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[3][0]); ?></td>
                                <td><?php echo e($output[3][1]); ?></td>
                                <td><?php echo e($output[3][2]); ?></td>
                                <td><?php echo e($output[3][3]); ?></td>
                                <td><?php echo e($output[3][4]); ?></td>
                                <td><?php echo e($output[3][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[4][0]); ?></td>
                                <td><?php echo e($output[4][1]); ?></td>
                                <td><?php echo e($output[4][2]); ?></td>
                                <td><?php echo e($output[4][3]); ?></td>
                                <td><?php echo e($output[4][4]); ?></td>
                                <td><?php echo e($output[4][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[5][0]); ?></td>
                                <td><?php echo e($output[5][1]); ?></td>
                                <td><?php echo e($output[5][2]); ?></td>
                                <td><?php echo e($output[5][3]); ?></td>
                                <td><?php echo e($output[5][4]); ?></td>
                                <td><?php echo e($output[5][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[6][0]); ?></td>
                                <td><?php echo e($output[6][1]); ?></td>
                                <td><?php echo e($output[6][2]); ?></td>
                                <td><?php echo e($output[6][3]); ?></td>
                                <td><?php echo e($output[6][4]); ?></td>
                                <td><?php echo e($output[6][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[7][0]); ?></td>
                                <td><?php echo e($output[7][1]); ?></td>
                                <td><?php echo e($output[7][2]); ?></td>
                                <td><?php echo e($output[7][3]); ?></td>
                                <td><?php echo e($output[7][4]); ?></td>
                                <td><?php echo e($output[7][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[8][0]); ?></td>
                                <td><?php echo e($output[8][1]); ?></td>
                                <td><?php echo e($output[8][2]); ?></td>
                                <td><?php echo e($output[8][3]); ?></td>
                                <td><?php echo e($output[8][4]); ?></td>
                                <td><?php echo e($output[8][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[9][0]); ?></td>
                                <td><?php echo e($output[9][1]); ?></td>
                                <td><?php echo e($output[9][2]); ?></td>
                                <td><?php echo e($output[9][3]); ?></td>
                                <td><?php echo e($output[9][4]); ?></td>
                                <td><?php echo e($output[9][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[10][0]); ?></td>
                                <td><?php echo e($output[10][1]); ?></td>
                                <td><?php echo e($output[10][2]); ?></td>
                                <td><?php echo e($output[10][3]); ?></td>
                                <td><?php echo e($output[10][4]); ?></td>
                                <td><?php echo e($output[10][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[11][0]); ?></td>
                                <td><?php echo e($output[11][1]); ?></td>
                                <td><?php echo e($output[11][2]); ?></td>
                                <td><?php echo e($output[11][3]); ?></td>
                                <td><?php echo e($output[11][4]); ?></td>
                                <td><?php echo e($output[11][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[12][0]); ?></td>
                                <td><?php echo e($output[12][1]); ?></td>
                                <td><?php echo e($output[12][2]); ?></td>
                                <td><?php echo e($output[12][3]); ?></td>
                                <td><?php echo e($output[12][4]); ?></td>
                                <td><?php echo e($output[12][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[13][0]); ?></td>
                                <td><?php echo e($output[13][1]); ?></td>
                                <td><?php echo e($output[13][2]); ?></td>
                                <td><?php echo e($output[13][3]); ?></td>
                                <td><?php echo e($output[13][4]); ?></td>
                                <td><?php echo e($output[13][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[14][0]); ?></td>
                                <td><?php echo e($output[14][1]); ?></td>
                                <td><?php echo e($output[14][2]); ?></td>
                                <td><?php echo e($output[14][3]); ?></td>
                                <td><?php echo e($output[14][4]); ?></td>
                                <td><?php echo e($output[14][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[15][0]); ?></td>
                                <td><?php echo e($output[15][1]); ?></td>
                                <td><?php echo e($output[15][2]); ?></td>
                                <td><?php echo e($output[15][3]); ?></td>
                                <td><?php echo e($output[15][4]); ?></td>
                                <td><?php echo e($output[15][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[16][0]); ?></td>
                                <td><?php echo e($output[16][1]); ?></td>
                                <td><?php echo e($output[16][2]); ?></td>
                                <td><?php echo e($output[16][3]); ?></td>
                                <td><?php echo e($output[16][4]); ?></td>
                                <td><?php echo e($output[16][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[17][0]); ?></td>
                                <td><?php echo e($output[17][1]); ?></td>
                                <td><?php echo e($output[17][2]); ?></td>
                                <td><?php echo e($output[17][3]); ?></td>
                                <td><?php echo e($output[17][4]); ?></td>
                                <td><?php echo e($output[17][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[18][0]); ?></td>
                                <td><?php echo e($output[18][1]); ?></td>
                                <td><?php echo e($output[18][2]); ?></td>
                                <td><?php echo e($output[18][3]); ?></td>
                                <td><?php echo e($output[18][4]); ?></td>
                                <td><?php echo e($output[18][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[19][0]); ?></td>
                                <td><?php echo e($output[19][1]); ?></td>
                                <td><?php echo e($output[19][2]); ?></td>
                                <td><?php echo e($output[19][3]); ?></td>
                                <td><?php echo e($output[19][4]); ?></td>
                                <td><?php echo e($output[19][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[20][0]); ?></td>
                                <td><?php echo e($output[20][1]); ?></td>
                                <td><?php echo e($output[20][2]); ?></td>
                                <td><?php echo e($output[20][3]); ?></td>
                                <td><?php echo e($output[20][4]); ?></td>
                                <td><?php echo e($output[20][5]); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e($output[21][0]); ?></td>
                                <td><?php echo e($output[21][1]); ?></td>
                               
                            </tr>
                            <tr>
                                <td><?php echo e($output[22][0]); ?></td>
                                <td><?php echo e($output[22][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[23][0]); ?></td>
                                <td><?php echo e($output[23][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[29][0]); ?></td>
                                <td><?php echo e($output[29][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[30][0]); ?></td>
                                <td><?php echo e($output[30][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[31][0]); ?></td>
                                <td><?php echo e($output[31][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[32][0]); ?></td>
                                <td><?php echo e($output[32][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[33][0]); ?></td>
                                <td><?php echo e($output[33][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[34][0]); ?></td>
                                <td><?php echo e($output[34][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[35][0]); ?></td>
                                <td><?php echo e($output[35][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[36][0]); ?></td>
                                <td><?php echo e($output[36][1]); ?></td>
                          
                            </tr>
                            <tr>
                                <td><?php echo e($output[37][0]); ?></td>
                                <td><?php echo e($output[37][1]); ?></td>
                                <td><?php echo e($output[37][2]); ?></td>
                                <td><?php echo e($output[37][3]); ?></td>
                                <td><?php echo e($output[37][4]); ?></td>
                                <td><?php echo e($output[37][5]); ?></td>
                            </tr>
                        
                            <tr>
                                <td><?php echo e($output[38][0]); ?></td>
                                <td><?php echo e($output[38][1]); ?></td>
                                <td><?php echo e($output[38][2]); ?></td>
                                <td><?php echo e($output[38][3]); ?></td>
                                <td><?php echo e($output[38][4]); ?></td>
                                <td><?php echo e($output[38][5]); ?></td>
                            </tr>


                        </tbody><?php /**PATH C:\xampp\htdocs\lokesh\resources\views/ajax/output.blade.php ENDPATH**/ ?>