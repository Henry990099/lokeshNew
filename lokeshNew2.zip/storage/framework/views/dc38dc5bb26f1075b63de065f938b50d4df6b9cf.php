
<div class="row">
    <div class="col-md-12">
        
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    
                    <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <?php $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $imagePath = "https://drive.google.com/uc?export=view&id=1xKBMVJv14FTjrUGOOAiymO6aNBa30G_r"; ?>
                      <?php $path = $value;
                        $id = explode("/",$path);
                        // if(!isset($id[5]))
                        //     continue;
                      ?>
                        <figure class="figure ">
                            <a data-id="<?php echo e($key2); ?>" data-value="<?php echo e($key2); ?>" class="subcat">
                            <?php if(isset($id[5])): ?>
                            <img src="https://drive.google.com/uc?export=view&id=<?php echo e($id[5]); ?>" class="img-fluid next-step" alt="" />
                            <?php else: ?>
                            <img src="<?php echo e(URL::asset('assets/images/dst.jpg')); ?>" class="img-fluid next-step" alt="" />
                            </a>
                            <?php endif; ?>
                            <figcaption class="figure-caption text-center" style="color:aliceblue"> <?php echo e($key2); ?></figcaption>
                        </figure>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
      
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="invan-feild mt-4">
                    <div class="inst-btn">
                        <button class="">INSTANT QUOTE? UPLOAD YOUR 3D MODEL <i class="fa-solid fa-cloud-arrow-up"></i></button>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </div>
</div>  

<script>
    
    $('.subcat').on('click', function(e) {
   e.preventDefault();
   var subcat = $(this).attr("data-id");
   var subval = $(this).attr("data-value");
   var urllink =  "<?php echo e(URL::asset('step-three')); ?>/"
   $.ajax({
       method: 'GET',
       url: urllink+subcat,
       success:function(result){
        var active = $(".wizard .nav-tabs li.active");
              active.next().removeClass("disabled");
              nextTab(active);
            $("#backup_material").html(result);
       },
   });
});


</script>
<?php /**PATH C:\Users\USER\Desktop\hk\lokeshNew2\resources\views/ajax/subCategory.blade.php ENDPATH**/ ?>