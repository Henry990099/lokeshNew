

<div class="row">
    <div class="col-md-12">
        <div class="inst-btn">
            <button class="">INSTANT QUOTE? UPLOAD YOUR 3D MODEL <i class="fa-solid fa-cloud-arrow-up"></i></button>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <?php $imagePath = "https://drive.google.com/uc?export=view&id=1xKBMVJv14FTjrUGOOAiymO6aNBa30G_r"; ?>
                    <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <?php $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $path = $value;
                        $id = explode("/",$path);
                      ?>
                        <figure class="figure ">
                            <a data-id="<?php echo e($key2); ?>" data-value="<?php echo e($key2); ?>" class="subcat">
                            <img src="https://drive.google.com/uc?export=view&id=<?php echo e($id[5]); ?>" class="img-fluid next-step" alt="" />
                            </a>
                            <figcaption class="figure-caption text-center" style="color:aliceblue"> <?php echo e($key2); ?></figcaption>
                        </figure>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
        <div class="quote-btn">
            <button>Retrive Saved Quote#</button>
        </div>
        <div class="feed-back">
            <h4>Feedback</h4>
        </div>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="invan-feild mt-4">
                    <input type="text" placeholder="Please input your valuable feedback/suggestions here" name="" style="height: 68px !important; font-size: 20px; border-radius: 10px;" />
                    <div class="d-flex justify-content-center">
                        <button class="submit_btn">SUBMIT <i class="fa-solid fa-envelope"></i></button>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </div>
</div>
        <script type="text/javascript">
            $(document).ready(function () {
                $(".nav-tabs > li a[title]").tooltip();
                $('a[data-toggle="tab"]').on("shown.bs.tab", function (e) {
                    var target = $(e.target);

                    if (target.parent().hasClass("disabled")) {
                        return false;
                    }
                });

                $(".next-step").click(function (e) {
                    var active = $(".wizard .nav-tabs li.active");
                    active.next().removeClass("disabled");
                    nextTab(active);
                });
                $(".prev-step").click(function (e) {
                    var active = $(".wizard .nav-tabs li.active");
                    prevTab(active);
                });
            });

            function nextTab(elem) {
                $(elem).next().find('a[data-toggle="tab"]').click();
            }
            function prevTab(elem) {
                $(elem).prev().find('a[data-toggle="tab"]').click();
            }

            $(".nav-tabs").on("click", "li", function () {
                $(".nav-tabs li.active").removeClass("active");
                $(this).addClass("active");
            });
        </script>

<script>
    
    $('.subcat').on('click', function(e) {
   
   e.preventDefault();
   var subcat = $(this).attr("data-id");
   var subval = $(this).attr("data-value");
   var urllink =  "<?php echo e(URL::asset('step-three')); ?>/"
   $.ajax({
       method: 'GET',
       url: urllink+subcat,
       success:function(result){
            $("#backup_material").html(result);
       },
   });
});
</script>
<?php /**PATH C:\Users\Furqan\Downloads\lokesh (1)\resources\views/ajax/subCategory.blade.php ENDPATH**/ ?>