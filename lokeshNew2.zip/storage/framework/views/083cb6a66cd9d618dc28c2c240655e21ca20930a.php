<?php if(!empty($dataProfileAndSqueeze['backup']) && $dataProfileAndSqueeze['backup']=="Y"): ?>
<div class="col-md-5 radio-heading">
    <div class="measure-type">
      <h6>BACKUP MATERIAL SELECTION</h6>
    </div>
    <input type="radio" id="html" class="inchMetric" name="fav_language" value="Inch" />
    <label for="html">Inch</label>
    <input type="radio" id="css" class="inchMetric" name="fav_language" class="ml-4" value="Metric" />
    <label for="css">Metric</label>
    <label class="custom-field-inv-select one mt-4">
      <select id="backup_material">
        <option>Please Select</option>
        <option value="POLYURETHANE" class="material">POLYURETHANE</option>
        <option value="ELASTOMERS" class="material">ELASTOMERS</option>
        <option value="PTFE" class="material">PTFE</option>
        <option value="THERMOPLASTIC">THERMOPLASTIC</option>
      </select>
      <span class="placeholder">MATERIAL FAMILY</span>
    </label>
    <label class="custom-field-inv-select one mt-3">
      <select id="backup_selecton">
        <option>Please Select</option>
      </select>
      <span class="placeholder">MATERIAL SELECTION</span>
    </label>
</div>
<?php endif; ?>
<?php if(!empty($dataProfileAndSqueeze['noofseals']) && $dataProfileAndSqueeze['noofseals'] == "3" ): ?>

<div class="col-md-5 radio-heading">
    <div class="measure-type">
      <h6>ENERGIZER</h6>
    </div>
    <label class="custom-field-inv-select one mt-4">
      <select id="energizer">
        <option>Please Select</option>
        <option value="POLYURETHANE" class="material">POLYURETHANE</option>
        <option value="ELASTOMERS" class="material">ELASTOMERS</option>
        <option value="PTFE" class="material">PTFE</option>
      </select>
      <span class="placeholder">MATERIAL FAMILY</span>
    </label>
</div>
<?php endif; ?>

<script>
    $('#backup_material').on('change',function (e) {
        alert($(this).val());
        var urllink =  "<?php echo e(URL::asset('backup-material')); ?>/"
        e.preventDefault();
        var backup=$(this).val();

        console.log(backup);

        $.ajax({
        method:'GET',
        url: urllink+backup,
        success:function(result){
            $("#backup_selecton").empty();
            $.each(result,function(val,key){                       
                $("#backup_selecton").append('<option value=' + val + '>' + val + '</option>');
            })
        },
        });
    });
</script><?php /**PATH C:\xampp\htdocs\lokesh\resources\views/ajax/backup_material.blade.php ENDPATH**/ ?>